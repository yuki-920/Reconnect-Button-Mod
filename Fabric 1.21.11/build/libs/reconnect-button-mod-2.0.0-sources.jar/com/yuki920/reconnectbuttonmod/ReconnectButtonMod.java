package com.yuki920.reconnectbuttonmod;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_642;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ReconnectButtonMod implements ClientModInitializer {

    public static final String MOD_ID = "reconnectbuttonmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static class_642 lastServerData = null;

    @Override
    public void onInitializeClient() {
        LOGGER.info("ReconnectButtonMod initialized.");
    }

    public static class_642 getLastServerData() {
        return lastServerData;
    }

    public static void setLastServerData(class_642 data) {
        lastServerData = data;
    }
}
