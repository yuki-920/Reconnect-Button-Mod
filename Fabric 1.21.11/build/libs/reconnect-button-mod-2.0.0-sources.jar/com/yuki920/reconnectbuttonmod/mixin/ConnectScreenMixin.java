package com.yuki920.reconnectbuttonmod.mixin;

import com.yuki920.reconnectbuttonmod.ReconnectButtonMod;
import net.minecraft.class_310;
import net.minecraft.class_412;
import net.minecraft.class_437;
import net.minecraft.class_639;
import net.minecraft.class_642;
import net.minecraft.class_9112;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_412.class)
public class ConnectScreenMixin {

    // コンストラクタではなく静的メソッド startConnecting を狙う
    @Inject(method = "startConnecting", at = @At("HEAD"))
    private static void onStartConnecting(class_437 screen, class_310 minecraft, class_639 serverAddress, class_642 serverData, boolean bl, class_9112 transferState, CallbackInfo ci) {
        if (serverData != null) {
            ReconnectButtonMod.setLastServerData(serverData);
            ReconnectButtonMod.LOGGER.info("[ReconnectButtonMod] Saved server: {}", serverData.field_3761);
        }
    }
}