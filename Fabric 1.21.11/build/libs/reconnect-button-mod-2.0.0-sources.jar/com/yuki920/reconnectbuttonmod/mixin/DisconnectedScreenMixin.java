package com.yuki920.reconnectbuttonmod.mixin;

import com.yuki920.reconnectbuttonmod.ReconnectButtonMod;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_412;
import net.minecraft.class_4185;
import net.minecraft.class_419;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_639;
import net.minecraft.class_642;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * DisconnectedScreen (切断画面) に「Reconnect」ボタンを追加する。
 * Mojang Mappings使用 (1.21.11)
 */
@Mixin(class_419.class)
public abstract class DisconnectedScreenMixin extends class_437 {

    protected DisconnectedScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void onInit(CallbackInfo ci) {
        class_642 serverData = ReconnectButtonMod.getLastServerData();

        // ① lastServerData が保存されているか確認
        ReconnectButtonMod.LOGGER.info("[ReconnectButtonMod] onInit fired. lastServerData={}",
                serverData != null ? serverData.field_3761 : "null");

        if (serverData == null) return;

        class_4185 backButton = null;
        for (var widget : this.method_25396()) {
            // ② children() に何が入っているか全件ログ出力
            ReconnectButtonMod.LOGGER.info("[ReconnectButtonMod] widget: {}", widget.getClass().getName());
            if (widget instanceof class_4185 btn) {
                backButton = btn;
            }
        }

        // ③ backButton が見つかったか確認
        ReconnectButtonMod.LOGGER.info("[ReconnectButtonMod] backButton={}", backButton);

        if (backButton == null) return;

        // ... ボタン追加処理

        final class_642 savedData = serverData;
        class_4185 reconnectButton = class_4185.method_46430(
                        class_2561.method_43471("gui.reconnectbuttonmod.reconnect"),
                        b -> class_412.method_36877(
                                new class_442(),
                                class_310.method_1551(),
                                class_639.method_2950(savedData.field_3761),
                                savedData,
                                false,
                                null
                        )

                )
                .method_46434(backButton.method_46426(), backButton.method_46427() + backButton.method_25364() + 4,
                        backButton.method_25368(), 20)
                .method_46431();

        this.method_37063(reconnectButton);
    }
}
