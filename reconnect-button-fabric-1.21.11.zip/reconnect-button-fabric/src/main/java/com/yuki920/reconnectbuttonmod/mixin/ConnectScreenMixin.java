package com.yuki920.reconnectbuttonmod.mixin;

import com.yuki920.reconnectbuttonmod.ReconnectButtonMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.client.multiplayer.chat.report.ReportEnvironment;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ConnectScreen が開かれるタイミングで現在の ServerData を保存する。
 * Mojang Mappings使用 (1.21.11)
 */
@Mixin(ConnectScreen.class)
public class ConnectScreenMixin {

    @Inject(
        method = "connect(Lnet/minecraft/client/Minecraft;Lnet/minecraft/client/multiplayer/resolver/ServerAddress;Lnet/minecraft/client/multiplayer/ServerData;Lnet/minecraft/client/multiplayer/chat/report/ReportEnvironment;)V",
        at = @At("HEAD")
    )
    private void onConnect(Minecraft minecraft, ServerAddress address, ServerData serverData,
                           ReportEnvironment reportEnvironment, CallbackInfo ci) {
        if (serverData != null) {
            ReconnectButtonMod.setLastServerData(serverData);
            ReconnectButtonMod.LOGGER.info("[ReconnectButtonMod] Saved server: {}", serverData.ip);
        }
    }
}
