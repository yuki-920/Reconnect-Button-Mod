package com.yuki920.reconnectbuttonmod.mixin;

import com.yuki920.reconnectbuttonmod.ReconnectButtonMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.DisconnectedScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * DisconnectedScreen (切断画面) に「Reconnect」ボタンを追加する。
 * Mojang Mappings使用 (1.21.11)
 */
@Mixin(DisconnectedScreen.class)
public abstract class DisconnectedScreenMixin extends Screen {

    protected DisconnectedScreenMixin(Component title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void onInit(CallbackInfo ci) {
        ServerData serverData = ReconnectButtonMod.getLastServerData();
        if (serverData == null) return;

        // 既存の最後のボタン（「Back to server list」）を探して位置の基準にする
        Button backButton = null;
        for (var widget : this.renderables) {
            if (widget instanceof Button btn) {
                backButton = btn;
            }
        }

        if (backButton == null) return;

        final ServerData savedData = serverData;
        final int btnX = backButton.getX();
        final int btnY = backButton.getY() + backButton.getHeight() + 4;
        final int btnW = backButton.getWidth();

        Button reconnectButton = Button.builder(
                Component.literal("Reconnect"),
                b -> ConnectScreen.startConnecting(
                    new DisconnectedScreen(new TitleScreen(), this.title, this.title),
                    Minecraft.getInstance(),
                    ServerAddress.parseString(savedData.ip),
                    savedData,
                    false,
                    null
                )
            )
            .bounds(btnX, btnY, btnW, 20)
            .build();

        this.addRenderableWidget(reconnectButton);
    }
}
